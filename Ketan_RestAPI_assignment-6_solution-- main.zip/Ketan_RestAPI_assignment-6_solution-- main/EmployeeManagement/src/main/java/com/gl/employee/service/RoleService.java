package com.gl.employee.service;

import com.gl.employee.entity.Role;

public interface RoleService {

	public String save(Role role);
}
